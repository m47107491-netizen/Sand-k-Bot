import { filter, listBoxes } from "../../../lib/store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  return Response.json({
    ok: true,
    filter: filter(),
    count: listBoxes(999).length,
    time: new Date().toISOString(),
  });
}
