import { filter, listBoxes } from "../../../lib/store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req) {
  const { searchParams } = new URL(req.url);
  const limit = Math.min(200, Math.max(1, Number(searchParams.get("limit") || 50)));
  const boxes = listBoxes(limit);
  return Response.json({
    filter: filter(),
    count: boxes.length,
    boxes,
  });
}
